
#> shopping_kart:v1.4.2/load/confirm_load
#
# @within	shopping_kart:v1.4.2/load/secondary
#

# Confirm load
tellraw @a[tag=convention.debug] {"text":"[Loaded ShoppingKart v1.4.2]","color":"green"}
scoreboard players set #shopping_kart.loaded load.status 1
function shopping_kart:v1.4.2/load/set_items_storage

scoreboard objectives add shopping_kart.data dummy
scoreboard objectives add shopping_kart.id dummy
scoreboard objectives add shopping_kart.engine dummy
scoreboard objectives add shopping_kart.max_engine dummy
scoreboard objectives add shopping_kart.motion_x dummy
scoreboard objectives add shopping_kart.motion_z dummy
scoreboard objectives add shopping_kart.predicted_pos_x dummy
scoreboard objectives add shopping_kart.predicted_pos_z dummy
scoreboard objectives add shopping_kart.old_pos_x dummy
scoreboard objectives add shopping_kart.old_pos_y dummy
scoreboard objectives add shopping_kart.old_pos_z dummy
scoreboard objectives add shopping_kart.booster_timer dummy
scoreboard objectives add shopping_kart.reactor_boost dummy
scoreboard objectives add shopping_kart.cruise_control dummy
scoreboard objectives add shopping_kart.collision_factor dummy
scoreboard objectives add shopping_kart.restitution dummy
scoreboard objectives add shopping_kart.hit_tick dummy

scoreboard objectives add shopping_kart.trigger_model trigger
scoreboard objectives add shopping_kart.current_model dummy

scoreboard players set #default_max_engine shopping_kart.data 1500
scoreboard players set #default_collision_factor shopping_kart.data 1000
scoreboard players set #default_restitution shopping_kart.data 500
scoreboard players set #player_lift shopping_kart.data 0

#define storage shopping_kart:main
#define storage shopping_kart:temp
#define score_holder #success
#define score_holder #valid
#define score_holder #count
#define score_holder #temp
#define score_holder #pos

## Setup tellraw prefix
data modify storage shopping_kart:main ShoppingKart set value [{"text":"[ShoppingKart]","color":"green"}]

scoreboard players set #-1 shopping_kart.data -1
scoreboard players set #2 shopping_kart.data 2
scoreboard players set #3 shopping_kart.data 3
scoreboard players set #10 shopping_kart.data 10
scoreboard players set #15 shopping_kart.data 15
scoreboard players set #20 shopping_kart.data 20
scoreboard players set #30 shopping_kart.data 30
scoreboard players set #60 shopping_kart.data 60
scoreboard players set #99 shopping_kart.data 99
scoreboard players set #100 shopping_kart.data 100
scoreboard players set #120 shopping_kart.data 120
scoreboard players set #1000 shopping_kart.data 1000
scoreboard players set #10000 shopping_kart.data 10000
scoreboard players set #14142 shopping_kart.data 14142

